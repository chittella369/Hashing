class Student:

    student_cgpa = ""
    student_id = ""
    student_hash_table_size = 30;
    StudentHashRecords=[[] for _ in range(student_hash_table_size)]


    StudentHallOfFameRecords = [[] for _ in range(student_hash_table_size)]
    StudentNewCourse = [[] for _ in range(student_hash_table_size)]
    StudentDeptDetails= [[] for _ in range(student_hash_table_size)]

    def initializeHash(self):
        self.StudentHashRecords = [[] for _ in range(self.student_hash_table_size)]

    def __init__(self,student_id,student_cgpa):
        self.student_id=student_id
        self.student_cgpa=student_cgpa

    def getascii_value(self):
        student_id = self.student_id
        student_id_ascii_val = 0
        for ch in student_id:
            student_id_ascii_val = student_id_ascii_val + ord(ch)
        return student_id_ascii_val





