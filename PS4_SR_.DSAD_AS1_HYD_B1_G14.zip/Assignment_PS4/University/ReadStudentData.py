"""
This program uses hashing algorithm (chained)
to read student data from an input file (prompts4.txt)
and insert it into a hash table.

The initial size of HashTable is 30.

Also, this program calculates the department wise average and
maximum CGPA for any department(assuming the input format is as specified)

Input = "C:\\assignment\\inputPS4.txt"
output = "c:\\assignment\\outputPS4.txt"
prompts = "c:\\assignment\\promptsPS4.txt"

"""
import datetime as d

from University.Student import Student

bucket = Student.StudentHashRecords
bucket_hall_of_fame = Student.StudentHallOfFameRecords
new_course_bucket = Student.StudentNewCourse
dept_cgpa_records= Student.StudentDeptDetails
student_dept_records = [1]
inputFile = "C:\\assignment\\inputPS4.txt"
outputFile = "c:\\assignment\\outputPS4.txt"
promptsFile = "c:\\assignment\\promptsPS4.txt"


"""
This function returns the hashfunction of the studentId 
"""
def hashfunction(StudentHashRecords, student_id_ascii):
    return (student_id_ascii) % len(StudentHashRecords)

"""
This function inserts the students records in the HashTable
Chained hashing is implemented in this function
"""
def insertStudentRecords(StudentHashRecords, hash_key, student_id, student_id_ascii, student_cgpa):
    key_exists = False
    bucket = StudentHashRecords[hash_key]
    if student_id_ascii == hash_key:
        key_exists = True

    if key_exists:
        bucket[hash_key] = ((student_id, student_cgpa))
    else:
        bucket.append((student_id, student_cgpa))

"""
This function reads the input file and calculates the hashkey for each studentId 
"""
def getStudentDetails():
    student = ""
    try:
        with open(inputFile) as txt_file:
            for line in txt_file:
                student_data = line.split('/')
                student_id = student_data[0]
                student_cgpa = student_data[1].rstrip('\n')

                student = Student(student_id, student_cgpa)

                student_id_ascii = student.getascii_value()
                hash_key = hashfunction(student.StudentHashRecords, student_id_ascii)
                insertStudentRecords(student.StudentHashRecords, hash_key, student_id, student_id_ascii, student_cgpa)

    except FileNotFoundError :
        print("file not found ")
    except Exception as ex:
        print("Exception is :", ex.__str__())
    finally:
        txt_file.close()

"""
This function outputs the list of all students who has the CGPA to enter 'Hall of Fame' 
"""
def hallOfFame(StudentHashRecords, hall_of_fame_cgpa):
    try:
        hall_of_fame_eligible_count = 0
        count = 0

        for kv in enumerate(bucket):
            k, v = kv
            value = v
            for each in value:
                if float(each[1]) >= hall_of_fame_cgpa:
                    bucket_hall_of_fame[count] = ((each[0], float(each[1])))
                    count = count + 1

        writeHallOfFame(bucket_hall_of_fame, hall_of_fame_cgpa)
    except Exception as ex:
        print("Exception is :", ex.__str__())

"""
This function outputs the list of students graduated in the last 5 years
and, whose CGPA satisfies the criteria for the new course
"""
def newCourseList(StudentHashRecords, CGPAFrom, CGPATo):
    try:
        hall_of_fame_eligible_count = 0
        count = 0
        for kv in enumerate(StudentHashRecords):
            k, v = kv
            value = v
            for each in value:
                if float(each[1]) >= CGPAFrom and float(each[1]) <= CGPATo:
                    new_course_bucket[count] = ((each[0], float(each[1])))
                    count = count + 1

        print("count : ", count)
        writeNewCourseList(new_course_bucket, CGPAFrom, CGPATo)
    except Exception as ex:
        print(ex)

"""
This function writes the list of students who entered 
the Hall of fame to the output file
"""
def writeHallOfFame(bucket_hall_of_fame, hall_of_fame_cgpa):
    try:
        filtered_list = [x for x in bucket_hall_of_fame if x]
        with open(outputFile, 'w') as output_file:
            output_file.write("---------- hall of fame ----------\n")
            output_file.write("Hall of Fame CGPA : " + str(hall_of_fame_cgpa) + "\n")
            output_file.write("Toal eligible Students :" + str(len(filtered_list)) + "\n")
            output_file.write("Qualified Students : " + "\n")

            for kv in enumerate(filtered_list):
                k, v = kv
                value = v
                output_file.write("\t" + str(value[0]) + " / " + str(value[1]))
                output_file.write("\n")

            output_file.write("--------------------\n")

    except Exception as ex:
        print(ex)
    finally:
        output_file.close()


"""
This function writes the list of students who satisy the criteria 
for the new course list to the output file
"""
def writeNewCourseList(new_course_bucket, new_course_offer_low, new_course_offer_high):
    try:

        filtered_new_course_candidate = [x for x in new_course_bucket if x]
        with open(outputFile, 'a') as output_file:
            output_file.write("---------- new course candidates ----------\n")
            output_file.write("Input :" + str(new_course_offer_low) + " to " + str(new_course_offer_high) + "\n")
            output_file.write("Toal eligible Students : " + str(len(filtered_new_course_candidate)) + "\n")
            output_file.write("Qualified Students : " + "\n")

            print("new_course_bucket : ", len(filtered_new_course_candidate))
            for kv in enumerate(filtered_new_course_candidate):
                k, v = kv
                value = v
                student_id = value[0]
                cgpa = value[1]
                year = student_id[0:4]
                current_year = int(d.datetime.now().year)

                if current_year - int(year) <= 5:
                    output_file.write("\t" + student_id + " / " + str(cgpa))
                    output_file.write("\n")

            output_file.write("--------------------\n")

    except Exception as ex:
        print(ex)
    finally:
        output_file.close()

"""
This function writes the Department wise average and max CGPA to the output file
"""

def writeDeptCGPA(deptCGPADetails):
    try:
        print("deptCGPADetails : ", deptCGPADetails)
        with open(outputFile, 'a') as dept_file:
            dept_file.write("---------- department CGPA ----------\n")
            index = 0
            for kva in enumerate(deptCGPADetails):
                if kva is not "":
                    k, v, a = kva[1]
                    dept = k
                    dept_avg = v
                    dept_max = a
                    dept_file.write(str(dept)  +" : max : "+ str(dept_max) +", avg : "+ str(dept_avg)  +"\n")
            dept_file.write("-------------------------------\n")
    except Exception as ex:
        print("Exception is :", ex.__str__())
    finally:
        dept_file.close()


"""
This function reads the criteria for the new course list from an text file
"""
def readNewCourseList():
    with open(promptsFile, 'r') as file:
        try:
            line = file.readlines()
            new_course_offer = line[1].split(":")
            new_course_offer_low = float(new_course_offer[1])
            new_course_offer_high = float(new_course_offer[2])
            newCourseList(Student.StudentHashRecords, new_course_offer_low, new_course_offer_high)
        except Exception as ex:
            print("Exception is :", ex.__str__())
        finally:
            file.close()

"""
This function reads the criteria for the new course list from an text file
"""
def getHallOfFame():
    with open(promptsFile, 'r') as file:
        try:
            line = file.readlines()
            hall_of_fame = line[0].split(":")
            hall_of_fame_cgpa = float(hall_of_fame[1])
            hallOfFame(Student.StudentHashRecords, hall_of_fame_cgpa)
        except Exception as ex:
            print("Exception is :", ex.__str__())
        finally:
            file.close()

"""
This function destroy's the HashTable
"""
def destroyHash(StudentHashRecords):
    try:
        non_empty_list = [x for x in StudentHashRecords if x]
        length = len(non_empty_list)
        while length > 0:
            element = non_empty_list[0]
            non_empty_list.remove(element)
            length = len(non_empty_list)
    except Exception as ex:
        print("Exception is :", ex.__str__())

    print("HashTable after destroy : ", non_empty_list)

"""
This function invokes the destroyHash function
"""
def deleteHash():
    destroyHash(Student.StudentHashRecords)


"""
This function filters and returns a unique department list from the student data file 
"""
def getDeptList(StudentHashRecords):
    non_empty_list = [x for x in StudentHashRecords if x]
    dept_list = []
    for each in (non_empty_list):
        for x, y in each:
            student_id = x
            dept = student_id[4:7]
            if dept_list.__contains__(dept)==False:
                dept_list.append(dept)

    return dept_list



"""
This function calculates the department wise average and maximum CGPA  
"""
def findDeptMaxAndAverage():
    try:
        dept_list = getDeptList(Student.StudentHashRecords)
        non_empty_list = [x for x in Student.StudentHashRecords if x]
        print("dept_list ", dept_list)
        dept_average_list = [[] for _ in range(len(dept_list))]
        index=0
        for dept in dept_list:
            cgpa,count,dept_max_cgpa = getCGPA(non_empty_list,dept)
            student_count = count
            total_cgpa = round(cgpa,2)
            dept_average = round(total_cgpa / student_count,2)
            if index==0:
                student_dept_records[index]=(dept,dept_average,total_cgpa)
            else:
                student_dept_records.append((dept,dept_average,total_cgpa))
            index= index+1

        writeDeptCGPA(student_dept_records)
    except Exception as ex:
        print("Exception is :", ex.__str__())

"""
This function calculates the average and maximum CGPA for a department
"""
def getCGPA(studentList, dept):
    try:
        length = len(studentList)
        count=0
        student_cgpa = 0.0
        cgpa=0.0
        max_cgpa = 0.0
        for student in studentList:
            element_count = len(student)
            for i in range(0, element_count):
                student_record = student[i]
                student_id = student_record[0]
                student_cgpa = student_record[1]
                student_dept = student_id[4:7]
                if(student_dept == dept):
                    cgpa = cgpa+float(student_cgpa)
                    count= count+ 1
                    if (float(max_cgpa) > float(student_cgpa)):
                        max_cgpa = max_cgpa
                    else:
                        max_cgpa = student_cgpa

                else:
                    continue

        return cgpa,count,max_cgpa
    except Exception as ex:
        print("Exception is :", ex.__str__())



"""
Initializing functions
"""
getStudentDetails()

getHallOfFame()

readNewCourseList()

findDeptMaxAndAverage()

deleteHash()